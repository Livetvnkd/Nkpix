package com.desi.equalizer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }

        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(WebAppInterface(this), "AndroidEQ")
        webView.loadUrl("file:///android_asset/index.html")
        setContentView(webView)
    }

    inner class WebAppInterface(private val mContext: Context) {

        @JavascriptInterface
        fun setEnabled(enabled: Boolean) {
            EqualizerForegroundService.isEqEnabled = enabled
            val serviceIntent = Intent(mContext, EqualizerForegroundService::class.java)
            if (enabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    mContext.startForegroundService(serviceIntent)
                } else {
                    mContext.startService(serviceIntent)
                }
            } else {
                EqualizerForegroundService.applyAll()
                mContext.stopService(serviceIntent)
            }
        }

        @JavascriptInterface
        fun setBandLevel(band: Int, level: Int) {
            if (band in 0..4) {
                EqualizerForegroundService.bandLevels[band] = level.toShort()
                EqualizerForegroundService.applyAll()
            }
        }

        @JavascriptInterface
        fun setBassBoost(strength: Int) {
            EqualizerForegroundService.bassStrength = strength.coerceIn(0, 1000).toShort()
            EqualizerForegroundService.applyAll()
        }
    }
}

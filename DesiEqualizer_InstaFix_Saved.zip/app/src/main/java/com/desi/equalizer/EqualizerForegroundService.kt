package com.desi.equalizer

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.pm.ServiceInfo
import android.media.audiofx.AudioEffect
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.IBinder

class EqualizerForegroundService : Service() {

    companion object {
        @Volatile var isEqEnabled: Boolean = false
        @Volatile var bandLevels: ShortArray = shortArrayOf(0, 0, 0, 0, 0)
        @Volatile var bassStrength: Short = 0

        private val sessionEqualizers = mutableMapOf<Int, Equalizer>()
        private val sessionBassBoosts = mutableMapOf<Int, BassBoost>()
        private val lock = Any()

        fun attachSession(sessionId: Int) {
            synchronized(lock) {
                try {
                    if (!sessionEqualizers.containsKey(sessionId)) {
                        val eq = Equalizer(100, sessionId)
                        sessionEqualizers[sessionId] = eq
                    }
                    if (!sessionBassBoosts.containsKey(sessionId)) {
                        val bb = BassBoost(100, sessionId)
                        sessionBassBoosts[sessionId] = bb
                    }
                    applyToSession(sessionId)
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        fun releaseSession(sessionId: Int) {
            if (sessionId == 0) return
            synchronized(lock) {
                try {
                    sessionEqualizers.remove(sessionId)?.release()
                    sessionBassBoosts.remove(sessionId)?.release()
                } catch (_: Exception) {}
            }
        }

        private fun applyToSession(sessionId: Int) {
            try {
                val eq = sessionEqualizers[sessionId]
                if (eq != null) {
                    val numBands = eq.numberOfBands.toInt()
                    for (i in 0 until minOf(numBands, bandLevels.size)) {
                        eq.setBandLevel(i.toShort(), bandLevels[i])
                    }
                    eq.enabled = isEqEnabled
                }
                val bb = sessionBassBoosts[sessionId]
                if (bb != null) {
                    bb.setStrength(bassStrength)
                    bb.enabled = isEqEnabled
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        fun applyAll() {
            synchronized(lock) {
                if (!sessionEqualizers.containsKey(0)) {
                    attachSession(0)
                }
                for (sessionId in sessionEqualizers.keys.toList()) {
                    applyToSession(sessionId)
                }
            }
        }

        fun releaseAll() {
            synchronized(lock) {
                for (eq in sessionEqualizers.values) {
                    try { eq.enabled = false; eq.release() } catch (_: Exception) {}
                }
                for (bb in sessionBassBoosts.values) {
                    try { bb.enabled = false; bb.release() } catch (_: Exception) {}
                }
                sessionEqualizers.clear()
                sessionBassBoosts.clear()
            }
        }
    }

    private val audioSessionReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            if (intent == null) return
            val sessionId = intent.getIntExtra(AudioEffect.EXTRA_AUDIO_SESSION, -1)
            if (sessionId <= 0) return
            when (intent.action) {
                AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION -> {
                    attachSession(sessionId)
                }
                AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION -> {
                    releaseSession(sessionId)
                }
            }
        }
    }

    override fun onCreate() {
        super.onCreate()
        val filter = IntentFilter().apply {
            addAction(AudioEffect.ACTION_OPEN_AUDIO_EFFECT_CONTROL_SESSION)
            addAction(AudioEffect.ACTION_CLOSE_AUDIO_EFFECT_CONTROL_SESSION)
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(audioSessionReceiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(audioSessionReceiver, filter)
        }
        attachSession(0)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val channelId = "equalizer_instafix_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Desi System Equalizer",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)

            val notification = Notification.Builder(this, channelId)
                .setContentTitle("Desi System Equalizer Active")
                .setContentText("Instagram, YouTube & System Audio Ready")
                .setSmallIcon(android.R.drawable.ic_lock_silent_mode_off)
                .build()

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PLAYBACK)
            } else {
                startForeground(1, notification)
            }
        }
        applyAll()
        return START_STICKY
    }

    override fun onDestroy() {
        try { unregisterReceiver(audioSessionReceiver) } catch (_: Exception) {}
        releaseAll()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}

package com.desi.equalizer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }

        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(WebAppInterface(this), "AndroidEQ")
        webView.loadUrl("file:///android_asset/index.html")
        setContentView(webView)
    }

    private fun initAudioEffects() {
        try {
            if (equalizer == null) {
                equalizer = Equalizer(0, 0)
            }
            if (bassBoost == null) {
                bassBoost = BassBoost(0, 0)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    inner class WebAppInterface(private val mContext: Context) {

        @JavascriptInterface
        fun setEnabled(enabled: Boolean) {
            initAudioEffects()
            try {
                equalizer?.enabled = enabled
                bassBoost?.enabled = enabled
            } catch (e: Exception) {
                e.printStackTrace()
            }

            val serviceIntent = Intent(mContext, EqualizerForegroundService::class.java)
            if (enabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    mContext.startForegroundService(serviceIntent)
                } else {
                    mContext.startService(serviceIntent)
                }
            } else {
                mContext.stopService(serviceIntent)
            }
        }

        @JavascriptInterface
        fun setBandLevel(band: Int, level: Int) {
            initAudioEffects()
            try {
                equalizer?.setBandLevel(band.toShort(), level.toShort())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        @JavascriptInterface
        fun setBassBoost(strength: Int) {
            initAudioEffects()
            try {
                bassBoost?.setStrength(strength.toShort())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}

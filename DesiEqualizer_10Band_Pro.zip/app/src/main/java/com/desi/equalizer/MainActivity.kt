package com.desi.equalizer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private var dynamicsProcessing: DynamicsProcessing? = null
    private var bassBoost: BassBoost? = null
    private val bandFreqs = floatArrayOf(
        31f, 62f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f
    )
    private var eq: DynamicsProcessing.Eq? = null

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }

        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(WebAppInterface(this), "AndroidEQ")
        webView.loadUrl("file:///android_asset/index.html")
        setContentView(webView)
    }

    private fun initAudioEffects() {
        try {
            if (dynamicsProcessing == null) {
                val config = DynamicsProcessing.Config.Builder(
                    DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                    1,
                    true,
                    bandFreqs.size,
                    false,
                    0,
                    false,
                    0,
                    true
                ).build()

                dynamicsProcessing = DynamicsProcessing(0, 0, config)
                eq = DynamicsProcessing.Eq(true, true, bandFreqs.size)
                for (i in bandFreqs.indices) {
                    val band = DynamicsProcessing.EqBand(true, bandFreqs[i], 0f)
                    eq?.setBand(i, band)
                }
                eq?.let {
                    dynamicsProcessing?.setPreEqAllChannelsTo(it)
                }
            }
            if (bassBoost == null) {
                bassBoost = BassBoost(0, 0)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    inner class WebAppInterface(private val mContext: Context) {

        @JavascriptInterface
        fun setEnabled(enabled: Boolean) {
            initAudioEffects()
            try {
                dynamicsProcessing?.enabled = enabled
                bassBoost?.enabled = enabled
            } catch (e: Exception) {
                e.printStackTrace()
            }

            val serviceIntent = Intent(mContext, EqualizerForegroundService::class.java)
            if (enabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    mContext.startForegroundService(serviceIntent)
                } else {
                    mContext.startService(serviceIntent)
                }
            } else {
                mContext.stopService(serviceIntent)
            }
        }

        @JavascriptInterface
        fun setBandLevel(bandIndex: Int, gainDb: Float) {
            initAudioEffects()
            try {
                if (bandIndex in bandFreqs.indices) {
                    val band = DynamicsProcessing.EqBand(true, bandFreqs[bandIndex], gainDb)
                    eq?.setBand(bandIndex, band)
                    dynamicsProcessing?.setPreEqBandAllChannelsTo(bandIndex, band)
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

        @JavascriptInterface
        fun setBassBoost(strength: Int) {
            initAudioEffects()
            try {
                bassBoost?.setStrength(strength.toShort())
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }
}

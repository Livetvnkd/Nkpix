package com.desi.equalizer

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.audiofx.BassBoost
import android.media.audiofx.DynamicsProcessing
import android.os.Build
import android.os.Bundle
import android.webkit.JavascriptInterface
import android.webkit.WebView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {

    private var dynamicsProcessing: DynamicsProcessing? = null
    private var bassBoost: BassBoost? = null
    private var currentFreqs: FloatArray = floatArrayOf(60f, 230f, 910f, 3600f, 14000f)
    private var eq: DynamicsProcessing.Eq? = null
    private var isEqEnabled: Boolean = false
    private val audioLock = Any()

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED
            ) {
                ActivityCompat.requestPermissions(
                    this,
                    arrayOf(Manifest.permission.POST_NOTIFICATIONS),
                    101
                )
            }
        }

        val webView = WebView(this)
        webView.settings.javaScriptEnabled = true
        webView.settings.domStorageEnabled = true
        webView.addJavascriptInterface(WebAppInterface(this), "AndroidEQ")
        webView.loadUrl("file:///android_asset/index.html")
        setContentView(webView)
    }

    private fun setupEngine(freqs: FloatArray, gains: FloatArray, enabled: Boolean, bassStrength: Int) {
        synchronized(audioLock) {
            try {
                val needsRebuild = dynamicsProcessing == null || !currentFreqs.contentEquals(freqs)
                if (needsRebuild) {
                    try {
                        dynamicsProcessing?.enabled = false
                        dynamicsProcessing?.release()
                    } catch (_: Exception) {}
                    dynamicsProcessing = null

                    currentFreqs = freqs.copyOf()
                    val config = DynamicsProcessing.Config.Builder(
                        DynamicsProcessing.VARIANT_FAVOR_FREQUENCY_RESOLUTION,
                        2,
                        true,
                        currentFreqs.size,
                        false,
                        0,
                        false,
                        0,
                        false
                    ).build()

                    dynamicsProcessing = DynamicsProcessing(0, 0, config)
                    eq = DynamicsProcessing.Eq(true, true, currentFreqs.size)
                }

                val activeEq = eq ?: DynamicsProcessing.Eq(true, true, currentFreqs.size).also { eq = it }
                for (i in currentFreqs.indices) {
                    val g = if (i < gains.size) gains[i] else 0f
                    val band = DynamicsProcessing.EqBand(true, currentFreqs[i], g)
                    activeEq.setBand(i, band)
                }
                dynamicsProcessing?.setPreEqAllChannelsTo(activeEq)
                dynamicsProcessing?.enabled = enabled
                isEqEnabled = enabled

                if (bassBoost == null) {
                    bassBoost = BassBoost(0, 0)
                }
                bassBoost?.setStrength(bassStrength.coerceIn(0, 1000).toShort())
                bassBoost?.enabled = enabled
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    private fun updateForegroundService(enabled: Boolean) {
        val serviceIntent = Intent(this, EqualizerForegroundService::class.java)
        try {
            if (enabled) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    startForegroundService(serviceIntent)
                } else {
                    startService(serviceIntent)
                }
            } else {
                stopService(serviceIntent)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }

    inner class WebAppInterface(private val mContext: Context) {

        @JavascriptInterface
        fun configureMode(freqsCsv: String, gainsCsv: String, enabled: Boolean, bassStrength: Int) {
            val freqs = freqsCsv.split(",").mapNotNull { it.trim().toFloatOrNull() }.toFloatArray()
            val gains = gainsCsv.split(",").mapNotNull { it.trim().toFloatOrNull() }.toFloatArray()
            if (freqs.isEmpty()) return
            setupEngine(freqs, gains, enabled, bassStrength)
            updateForegroundService(enabled)
        }

        @JavascriptInterface
        fun setEnabled(enabled: Boolean) {
            synchronized(audioLock) {
                isEqEnabled = enabled
                try {
                    dynamicsProcessing?.enabled = enabled
                    bassBoost?.enabled = enabled
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
            updateForegroundService(enabled)
        }

        @JavascriptInterface
        fun setBandLevel(bandIndex: Int, gainDb: Double) {
            synchronized(audioLock) {
                try {
                    if (dynamicsProcessing == null) {
                        val zeros = FloatArray(currentFreqs.size) { 0f }
                        setupEngine(currentFreqs, zeros, isEqEnabled, 0)
                    }
                    if (bandIndex in currentFreqs.indices) {
                        val band = DynamicsProcessing.EqBand(true, currentFreqs[bandIndex], gainDb.toFloat())
                        eq?.setBand(bandIndex, band)
                        dynamicsProcessing?.setPreEqBandAllChannelsTo(bandIndex, band)
                        eq?.let { dynamicsProcessing?.setPreEqAllChannelsTo(it) }
                    }
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }

        @JavascriptInterface
        fun setBassBoost(strength: Int) {
            synchronized(audioLock) {
                try {
                    if (bassBoost == null) {
                        bassBoost = BassBoost(0, 0)
                    }
                    bassBoost?.setStrength(strength.coerceIn(0, 1000).toShort())
                    bassBoost?.enabled = isEqEnabled
                } catch (e: Exception) {
                    e.printStackTrace()
                }
            }
        }
    }
}
